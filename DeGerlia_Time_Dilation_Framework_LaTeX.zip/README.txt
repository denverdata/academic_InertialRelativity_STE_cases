DeGerlia Time Dilation Framework — LaTeX project
================================================

Files in this bundle
  DeGerlia_Time_Dilation_Framework.tex  Main document (RSC template + framework).
  pair_tables.tex                        \input by the main file: Table 1 + Table 2 (Groups A-E).
  rsc.bib                                Bibliography database.
  DeGerlia_Time_Dilation_Framework_PREVIEW.pdf
                                         Sandbox-rendered preview (placeholder logos,
                                         plainnat bib) — for content review only.

Also required to build (already in your repo, not included here)
  rsc.bst            RSC bibliography style (\bibliographystyle{rsc}).
  head_foot/         Title-block images: dec, RSC_LOGO_CMYK, DOI, dates, LF.
  Packages: droidsans, mhchem (present in a full TeX Live install).

Build
  pdflatex DeGerlia_Time_Dilation_Framework
  bibtex   DeGerlia_Time_Dilation_Framework
  pdflatex DeGerlia_Time_Dilation_Framework
  pdflatex DeGerlia_Time_Dilation_Framework

Notes
  - All numbers are full precision rounded once to six significant figures.
  - GTD is shown in the 1 - delta form throughout.
  - The s/d split (k_s vs k_d, GTD_s vs GTD_d) uses the published 6-figure
    D_crit for the DeGerlia route; last-digit differences are calculation
    precision, not physics.
